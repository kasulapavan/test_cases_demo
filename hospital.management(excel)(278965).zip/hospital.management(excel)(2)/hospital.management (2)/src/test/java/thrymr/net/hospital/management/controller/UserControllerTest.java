package thrymr.net.hospital.management.controller;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class UserControllerTest {

    @BeforeEach
    void setUp() {
    }

    @Test
    void save() {
    }

    @Test
    void update() {
    }

    @Test
    void signIn() {
    }

    @Test
    void deleteById() {
    }

    @Test
    void associate() {
        System.out.println("hello");
    }

    @Test
    void disassociate() {
    }
}