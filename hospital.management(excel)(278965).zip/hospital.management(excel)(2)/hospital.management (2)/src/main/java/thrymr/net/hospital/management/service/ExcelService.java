package thrymr.net.hospital.management.service;

import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

/**
 * @author Sneha
 * @ProjectName hospital.management (2)
 * @since 26-08-2023
 */
public interface ExcelService {
    public void getExcel(HttpServletResponse response) throws IOException;
}