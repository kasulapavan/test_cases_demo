package thrymr.net.hospital.management.enums;

public enum RoleType {
    ADMIN,
    DOCTOR

}
