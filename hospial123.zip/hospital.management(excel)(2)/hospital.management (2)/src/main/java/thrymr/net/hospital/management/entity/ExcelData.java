package thrymr.net.hospital.management.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author Sneha
 * @ProjectName hospital.management (2)
 * @since 26-08-2023
 */
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Data
public class ExcelData {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private  String resourceId;
    private String resourceName;

    private String resourceType;

    private String activityID;
    private String activityName;
    private String wbs;
    private String wbsName;
    private String soeID;
    private String start;
    private String finish;

    private String unitOfMeasure;

    private String budgetedUnits;

    private String remainingUnits;

    private String actualUnits;
    private String calendar;
    private String curve;
    private String spreadsheetField;
    @Column(columnDefinition = "TEXT")
    private String dates;
}