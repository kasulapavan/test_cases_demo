package thrymr.net.hospital.management;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.info.License;
import org.modelmapper.ModelMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.server.Session;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;


@SpringBootApplication
@OpenAPIDefinition(info = @Info(
		title = "Sports Swagger Test",
		version = "2.0.0",
		description = "This is for Learning Only!!",
		termsOfService = "sneha",
		contact = @Contact(
				name = "Sneha Kamisetty",
				email = "sneha@gmail.com"
		),
		license = @License(
				name = "Sneha",
				url = "www.sneha.com"
		)
)
)
public class HospitalManagement {
	@Bean
	public ModelMapper modelMapper(){
		return new ModelMapper();
	}
	public static void main(String[] args) {
		SpringApplication.run(HospitalManagement.class, args);

//		try {
//			// Your code that may throw exceptions
//		} catch (Exception e) {
//			logger.error("An exception occurred:", e);
//			sendExceptionEmail(e);
//		}

	}
		@Bean
		public BCryptPasswordEncoder bCryptPasswordEncoder(){
			return new BCryptPasswordEncoder();
		}
}


//import org.slf4j.Logger;


//public class ExceptionHandlingAndEmail {
//	private static final Logger logger = LoggerFactory.getLogger(ExceptionHandlingAndEmail.class);
//
//	public static void main(String[] args) {
//		try {
//			// Your code that may throw exceptions
//		} catch (Exception e) {
//			logger.error("An exception occurred:", e);
//			sendExceptionEmail(e);
//		}
//	}




